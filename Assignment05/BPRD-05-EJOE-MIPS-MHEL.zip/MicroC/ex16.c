// micro-C example 16 -- more optimization needed

void main(int n) {
  if (n) 
    { } 
  else 
    print 1111;
  print 2222;
}
